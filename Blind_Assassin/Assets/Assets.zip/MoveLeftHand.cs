﻿/*2016039005 최윤성
 *unity 예제 과제
 *3d 평면 상에서 캐릭터가 전후좌우로 움직이며,
 *나아갈 방향을 애니메이션으로 보여주게 설정해봄*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Threading;
public class MoveLeftHand : MonoBehaviour
{
    public GameObject hands;
    void Update()
    {


       


       

            hands.SetActive(true);
           

        
      
          


    


    }
}

